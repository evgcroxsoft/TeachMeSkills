import asyncio

async def send_email():
    await asyncio.sleep(5)
    print('You have new reservation, please check it!')
    return
